import { LoginServiceService } from '../login-service.service';
import { Router } from '@angular/router';
import { Component, OnInit, Input } from '@angular/core';
import { Employee } from '../model/employeeDetails';
@Component({
  selector: 'app-employeedetails',
  templateUrl: './employeedetails.component.html',
  styleUrls: ['./employeedetails.component.css']
})
export class EmployeedetailsComponent implements OnInit {
  @Input('contact') contactval;
  employeeDetailsArr: Employee[] = [];
  employeeArr: Employee[] = [];
  allEmailId: [];
  trial: any;
  emailCheck: boolean;
  employee: Employee;
  constructor(private service: LoginServiceService, private router: Router) 
  { 
    this.employee = new Employee();
  }

  ngOnInit() {
  }
  addEmployee() {
    this.service.addEmployee(this.employee).subscribe(
      data => {
        console.log(data);
        alert('Employee details saved successfully.')
        this.router.navigate(['/admin']);
        
      });
  }
  getEmployee() {
    this.service.getEmployee().subscribe(res=>{
      this.employeeArr=res;
      if(this.employeeArr.length===0)
      {
      this.addEmployee();
      this.router.navigate(['/admin']);
    }
    
    for (const u of this.employeeArr) {
    
      if (this.employee.employeeEmailId !== u.employeeEmailId ) {
        this.emailCheck = true;
    }
    else {
      this.emailCheck = false;
      alert('employee already exists');
      break;
    }
  }
  if (this.emailCheck) {
    this.addEmployee();
    this.router.navigate(['/admin']);
  }
  
  });
}

}
