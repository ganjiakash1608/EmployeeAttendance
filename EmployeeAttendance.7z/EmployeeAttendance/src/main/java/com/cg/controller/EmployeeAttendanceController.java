package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Admin;
import com.cg.entity.Employee;
import com.cg.service.AdminService;
import com.cg.service.EmployeeService;

//@CrossOrigin("http://localhost:4200")
@RestController
public class EmployeeAttendanceController {

	@Autowired
	AdminService adminservice;

	@Autowired
	EmployeeService employeeservice;

	@GetMapping(path = "/getAdmin", produces = "application/json")
	public List<Admin> getAdminList() {
		return (List<Admin>) adminservice.getAdminList();
	}

	@GetMapping(path = "/getEmployee", produces = "application/json")
	public List<Employee> getEmployeeList() {
		return (List<Employee>) employeeservice.getEmployeeList();
	}

	@PostMapping(path = "/addEmployee", consumes = "application/json", produces = "application/json")
	public Employee addEmployee(@RequestBody Employee e) {
		return employeeservice.addEmployee(e);
	}

	@PutMapping(path = "/updateemployee", consumes = "application/json", produces = "application/json")
	public Employee updateEmployee(@RequestBody Employee e) {
		
			return employeeservice.addEmployee(e);

	}

}
