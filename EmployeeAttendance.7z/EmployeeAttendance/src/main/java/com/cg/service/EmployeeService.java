package com.cg.service;

import java.util.List;

import com.cg.entity.Employee;

public interface EmployeeService {

	public Employee addEmployee(Employee e);

	public List<Employee> getEmployeeList();
}
