package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Admin;
import com.cg.service.AdminService;

@CrossOrigin("http://localhost:4200")
@RestController
public class EmployeeAttendanceController {

	@Autowired
	AdminService adminservice;
	
	@GetMapping(path = "/getAdmin", produces = "application/json")
	public List<Admin> getAdminList() {
		return (List<Admin>) adminservice.getAdminList();
	}
	
}
