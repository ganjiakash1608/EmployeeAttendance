import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { LoginServiceService } from '../login-service.service';
import { Employee } from '../model/employeeDetails';
import { LOP } from '../model/lop';
import { getLocalePluralCase } from '@angular/common';

@Component({
  selector: 'app-calculate-lop',
  templateUrl: './calculate-lop.component.html',
  styleUrls: ['./calculate-lop.component.css']
})
export class CalculateLopComponent implements OnInit {

  empid: number;
  showEmp = false;
  pl: number;
  leave: number;
  showLop = false;
  lop: LOP;
  submitFlag = true;

  constructor(private router: Router, private service: LoginServiceService, private ref: ChangeDetectorRef) {
    this.lop = new LOP();
    this.empid = JSON.parse(localStorage.getItem("LOPEMPID"));
    this.pl = 2;
  }

  ngOnInit() {
  }

  loadLop() {   
    this.service.getLop(this.empid, this.lop.month).subscribe(res => {
      console.log("lop111 "+ res);
      if (res != null) {
        this.lop = res;  
        this.showLop = true; 
        this.submitFlag = false; 
      }else{
        this.lop.totalDays =  0;
        this.showLop = false; 
        this.submitFlag = true;
      }
      
    });
    this.loadEmp();
  }

  back(){
    this.router.navigate(['/lop']);
  }

  loadEmp() {
    this.showEmp = true;
    this.service.getEmployeeById(this.empid).subscribe(res => {
      this.lop.empFromLop = res as Employee;
    });
    this.loadLeaveCount();
  }

  loadLeaveCount() {
    this.service.loadleaveCount(this.empid, this.lop.month).subscribe(res => {
      console.log("lc " + res);
      this.leave = res as number;
    });
  }

  calculate() {
    console.log("calculation start");

    let leavesToCal = this.leave - this.pl;
    console.log("ltc " + leavesToCal);
    if (leavesToCal > 0) {
      this.lop.lop = Number((this.lop.empFromLop.salary - ((this.lop.empFromLop.salary / this.lop.totalDays))*leavesToCal).toFixed());
    } else {
      this.lop.lop = this.lop.empFromLop.salary;
    }
    this.showLop = true;
  }

  submit() {
    this.lop.year = (new Date()).getFullYear();
    this.service.submitLop(this.lop).subscribe(res => {
      console.log(res);
      this.router.navigate(['/lop']);
    });
  }

  update(){
    this.service.submitLop(this.lop).subscribe(res => {
      console.log(res);
      this.router.navigate(['/lop']);
    });
  }
}
