import { Employee } from './employeeDetails';

export class LOP {

    id: number;
    month: number;
    empFromLop: Employee;
    year : number;
    lop : number;
    totalDays: number;
}