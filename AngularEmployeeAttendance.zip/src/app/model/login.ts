export class Login {
    adminEmailId: String;
    password: String;
}
