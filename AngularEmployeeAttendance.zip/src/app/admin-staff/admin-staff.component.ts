import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-staff',
  templateUrl: './admin-staff.component.html',
  styleUrls: ['./admin-staff.component.css']
})
export class AdminStaffComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
