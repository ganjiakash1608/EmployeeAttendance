import { Component, OnInit } from '@angular/core';
import { Employee } from '../model/employeeDetails';
import { LoginServiceService } from '../login-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  employeeArr:Employee[] = [];
  constructor(private router: Router, private service: LoginServiceService) { 
    this.getEmployee();
  }

  ngOnInit() {
    this.getEmployee();
  }
  getEmployee() {
    console.log(this.employeeArr);
    this.service.getEmployee().subscribe(res => {
      this.employeeArr = (res);
      JSON.stringify(this.employeeArr);
      console.log(this.employeeArr);
      return this.employeeArr;
    });
  }
  
}
