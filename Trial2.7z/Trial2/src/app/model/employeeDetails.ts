export class Employee {
    id: number;
    firstName: string;
    lastName: string;
    employeeEmailId: string;
    employeeContact: string;
    employeeDesignation: string;
    employeeDOB:string;
    employeeGender: string;
    
}