export class Employee {
    id: number;
    firstName: string;
    lastName: string;
    EmployeeEmailId: string;
    EmployeeContact: string;
    Designation: string;
    EmployeeDOB:string;
    EmployeeGender: string;
    
}