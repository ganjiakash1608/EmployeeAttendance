import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Login } from './model/login';
@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {
  baseUrl = "http://localhost:8888";
  constructor(private http: HttpClient) { }

  getAdmin(): Observable<Login[]>{

    return this.http.get<Login[]>(this.baseUrl +'/getAdmin');
 }
}
